#=========Selectors/Subjects===========

#1.start basic server_name

nats-server -js

nats pub orders.ca.sf.abc333.high_value '{"orderid":"12345","item": "tag789","price": 320,"store": "abc333"","city": "SF","state": "CA"}'

#Selector A:

nats sub 'orders.ca.sf.>''
nats pub orders.ca.sf.abc333.high_value '{"orderid":"12345","item": "tag789","price": 320,"store": "abc333"","city": "SF","state": "CA"}'
nats pub orders.ca.la.abc333.high_value '{"orderid":"12345","item": "tag789","price": 320,"store": "abc333"","city": "SF","state": "CA"}'

#Selector B:

nats sub 'orders.ca.*.>'
nats pub orders.ca.sf.abc333.high_value '{"orderid":"12345","item": "tag789","price": 320,"store": "abc333"","city": "SF","state": "CA"}'
nats pub orders.ca.la.abc333.high_value '{"orderid":"12345","item": "tag789","price": 320,"store": "abc333"","city": "SF","state": "CA"}'

#Selector C:

nats sub orders.ca.*.*.high_value
nats sub orders.ca.sf.abc333.high_value
nats sub orders.ca.*.*.low_value


#=========Accounts/VPN===============

# 1) ---centralized security - Accounts vs. VPNs

#a) start test sever (from the NATS_DEMO/Citi_Demo folder)- 2 accounts, user/password , permissions...
 nats-server -c Accounts_VPN/hub.conf

 nats sub test -s nats://localhost:1234 --no-context
 nats sub test -s nats://localhost:1234 --no-context --user user_a --password user_a
 nats sub "a.public.>" -s nats://localhost:1234 --no-context --user user_a --password user_a

 nats pub a.public.stock "trade data A" -s nats://localhost:1234 --user user_a --password user_a --no-context
 nats pub a.public.stock "trade data B" -s nats://localhost:1234 --user user_b --password user_b --no-context

#b)  give access to user_b for a.public.> - and observe that even if  you can publish, the message does not cross the account boundary.
#c)  reload the config
 ps -e|grep nats # get the PID
 nats-server --signal reload=<PID>

 nats pub a.public.stock "trade data B" -s nats://localhost:1234 --user user_b --password user_b --no-context

#d) now set up the imports and exports.
# reload config
ps -e|grep nats # get the PID
nats-server --signal reload=<PID>

nats pub a.public.stock "trade data D" -s nats://localhost:1234 --user user_b --password user_b --no-context
#nats pub imported.a.stock.private "trade data" -s nats://localhost:1234 --user user_b --password user_b --no-context


#==========Partitioned Consumer Groups/ Partitioned Queues=========

#1 Create context - this should alreadybe done
nats context save local --server nats://localhost:4222 --description "Local Host"   
nats context select local

#2 star a basic server ensure you shutdown the previous server instance.

nats-server -js

#3 create static stream

nats stream add ORDERS_STATIC --subjects="orders.*" --transform-source="orders.*" --transform-destination="{{partition(10,1)}}.orders.{{wildcard(1)}}" --defaults

nats stream info ORDER_STATIC

#4. create static consumer group with 2 members
cg static create balanced ORDERS_STATIC s-consumer-grp 10 m1 m2 --filter '>'

cg static info ORDERS_STATIC s-consumer-grp

#5. add consumers:

cg static consume ORDERS_STATIC s-consumer-grp m1 --sleep 25ms
cg static consume ORDERS_STATIC s-consumer-grp m1 --sleep 25ms
cg static consume ORDERS_STATIC s-consumer-grp m2 --sleep 25ms
cg static consume ORDERS_STATIC s-consumer-grp m2 --sleep 25ms
cg static info ORDERS_STATIC s-consumer-grp

#6. check KVStore for consumer group config:
nats kv ls
nats kv ls static-consumer-groups
kv get static-consumer-groups ORDERS_STATIC.s-consumer-grp


#7. generate traffic

nats bench js pub sync orders --multisubject --sleep 10ms --multisubjectmax 100 --stream ORDERS_STATIC

#8. shutdown one consumer to observer standby takeover

cg static step-down ORDERS_STATIC s-consumer-grp m2

#9. ---create ELASTIC stream----

nats stream add ORDERS_DYNAMIC --subjects="orders_d.*" --defaults

#10. create dynamic consumer groups

cg elastic create ORDERS_DYNAMIC d-consumer-grp 10
filter (empty when done): orders_d.*

nats stream ls


#11. Create a watcher.

watch -n 1 'nats stream info ORDERS_DYNAMIC-d-consumer-grp --json | jq "{Messages: .state.messages, Bytes: .state.bytes, FirstSeq: .state.first_seq, LastSeq: .state.last_seq}"'   


#12. add a member to the consumer groups
cg elastic add ORDERS_DYNAMIC d-consumer-grp m1

cg elastic info ORDERS_DYNAMIC d-consumer-grp

#13. add a consumer+standby

cg elastic consume ORDERS_DYNAMIC d-consumer-grp m1
cg elastic consume ORDERS_DYNAMIC d-consumer-grp m1

#14. generate data

nats bench js pub sync orders_d --multisubject --sleep 10ms --multisubjectmax 100 --stream ORDERS_DYNAMIC

cg elastic info ORDERS_DYNAMIC d-consumer-grp


#15. add 2 more members

cg elastic add ORDERS_DYNAMIC d-consumer-grp m2 m3

cg elastic info ORDERS_DYNAMIC d-consumer-grp

#16. start consumers

cg elastic consume ORDERS_DYNAMIC d-consumer-grp m2
cg elastic consume ORDERS_DYNAMIC d-consumer-grp m3
cg elastic info ORDERS_DYNAMIC d-consumer-grp

#17. Stop one of the consumers
#first step dfown to allowthe standyto kickin
cg elastic step-down ORDERS_DYNAMIC d-consumer-grp m1
#then sutdown to take the member off line
cg elastic drop ORDERS_DYNAMIC d-consumer-grp m1

cg elastic info ORDERS_DYNAMIC d-consumer-grp


#18. add the originalmember back in

cg elastic add ORDERS_DYNAMIC d-consumer-grp m1




#========Leaf Nodes Topologies============

#startup the clusters
docker compose -f LeafNodes/compose-cluster-leaf.yml up

# 0. testcluster

nats server list -s nats://localhost:4772 --user sys --password sys
nats server list -s nats://localhost:4775 --user sys --password sys


# 1. create original  stream nn the leaf node.

nats stream add IOT_LEAF_STREAM --user user_leaf --password password -s nats://localhost:4775 --subjects "iot.data.>" --storage file --defaults


 nats stream ls -s nats://localhost:4775 --user user_leaf --password password
 nats stream report -s nats://localhost:4775 --user user_leaf --password password

#2. Create sourced stream on Node 1 - note yo must mention LEAF_DOMAIN for config

nats stream add NODE1_IOT_STREAM --user user_a --password password -s nats://localhost:4772 --storage=file --source=IOT_LEAF_STREAM --defaults


nats stream ls -s nats://localhost:4772 --user user_a --password password
nats stream report -s nats://localhost:4772 --user user_a --password password

#3. Create 2 consumers one on the Leaf Node and one on the Hub node - make them push consumers

# deliver to iot.hub.consumer
nats consumer add NODE1_IOT_STREAM MY_HUB_CONSUMER -s nats://localhost:4772 --user user_a --password password
# deliver to iot.leaf.consumer
nats consumer add IOT_LEAF_STREAM MY_LEAF_CONSUMER -s nats://localhost:4775 --user user_leaf --password password

nats consumer report IOT_LEAF_STREAM  -s nats://localhost:4775 --user user_leaf --password password
nats consumer report NODE1_IOT_STREAM  -s nats://localhost:4772 --user user_a --password password


#4. create subscriber for consumers.

nats sub iot.hub.consumer -s nats://localhost:4772 --user user_a --password password
nats sub iot.leaf.consumer -s nats://localhost:4775 --user user_leaf --password password


#5. Test out synchronization

nats pub iot.data.test1 "message 1" --user user_leaf --password password -s nats://localhost:4775 --count 5
#nats pub iot.data.test2 "message 2" --user user_leaf --password password -s nats://localhost:4775 --count 5

nats stream --user user_leaf --password password -s nats://localhost:4775 ls
nats stream --user user_leaf --password password -s nats://localhost:4775 view

nats stream --user user_a --password password -s nats://localhost:4772 ls
nats stream --user user_a --password password -s nats://localhost:4772 view


#6. show store and forward - Shutdown consumer 1
docker ps
Docker stop leafnodes-hub-1-1
docker ps


#7. publish some more messages
nats pub iot.data.test1 "message 3" --user user_leaf --password password -s nats://localhost:4775 --count 5

nats stream --user user_leaf --password password -s nats://localhost:4775 ls
nats stream --user user_a --password password -s nats://localhost:4772 ls

#8. restart node
docker start leafnodes-hub-1-1
docker ps

nats stream --user user_a --password password -s nats://localhost:4772 ls



#===========CLEANUP VPN======

cp Accounts_VPN/acc-hub1.conf Accounts_VPN/acc-hub.conf

#===========CLEANUP PARITIONS======
nats-server -js

cg static delete ORDERS_STATIC s-consumer-grp
cg static delete ORDERS_DYNAMIC d-consumer-grp

nats stream delete ORDERS_STATIC
nats stream delete ORDERS_DYNAMIC
nats stream delete ORDERS_DYNAMIC-d-consumer-grp

nats kv del static-consumer-groups
nats kv del static-consumer-groups

#===========CLEANUP LEAFNODES======

docker compose -f LeafNodes/compose-cluster-leaf.yml up

nats stream purge IOT_LEAF_STREAM -s nats://localhost:4775 --user user_leaf --password password
nats stream purge NODE1_IOT_STREAM -s nats://localhost:4772 --user user_a --password password


nats consumer rm MY_LEAF_CONSUMER -s nats://localhost:4775 --user user_leaf --password password
nats consumer rm MY_HUB_CONSUMER -s nats://localhost:4772 --user user_a --password password

nats stream rm IOT_LEAF_STREAM -s nats://localhost:4775 --user user_leaf --password password
nats stream rm NODE1_IOT_STREAM -s nats://localhost:4772 --user user_a --password password
