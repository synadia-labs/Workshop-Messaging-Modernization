
#====== TEST stream sourcing accross a 3 node cluster + Leaf Node ====

# 0. testcluster

nats server list -s nats://localhost:4772 --user sys --password sys
nats server list -s nats://localhost:4775 --user sys --password sys


# 1. create original  stream nn the leaf node.

nats stream add IOT_LEAF_STREAM --user user_leaf --password password -s nats://localhost:4775 --subjects "iot.data.>" --storage file --defaults


 nats stream ls -s nats://localhost:4775 --user user_leaf --password password
 nats stream report -s nats://localhost:4775 --user user_leaf --password password

#2. Create sourced stream on Node 1

nats stream add NODE1_IOT_STREAM --user user_a --password password -s nats://localhost:4772 --storage=file --tag "node:1" --source=IOT_LEAF_STREAM --defaults


nats stream ls -s nats://localhost:4772 --user user_a --password password
nats stream report -s nats://localhost:4772 --user user_a --password password

#3. Create sourced stream on Node 2

nats stream add NODE2_IOT_STREAM --user user_b --password password -s nats://localhost:4773 --storage=file --tag "node:2" --source=IOT_LEAF_STREAM --defaults

nats stream ls -s nats://localhost:4773 --user user_b --password password
nats stream report -s nats://localhost:4773 --user user_b --password password

#4. Test out synchronization


nats pub iot.data.test1 "message 1" --user user_leaf --password password -s nats://localhost:4775
nats pub iot.data.test2 "message 2" --user user_leaf --password password -s nats://localhost:4775

nats stream --user user_leaf --password password -s nats://localhost:4775 ls
nats stream --user user_leaf --password password -s nats://localhost:4775 view
nats stream --user user_a --password password -s nats://localhost:4772 ls
nats stream --user user_b --password password -s nats://localhost:4773 ls


# 5. simulate store and forward

docker compose -f compose-cluster-leaf.yml ps
docker compose -f compose-cluster-leaf.yml stop hub-2

nats pub iot.data.test1 "message test" --user user_leaf --password password -s nats://localhost:4775 --count 10

nats stream --user user_a --password password -s nats://localhost:4772 ls
nats stream --user user_b --password password -s nats://localhost:4773 ls

docker compose -f compose-cluster-leaf.yml start hub-2

nats stream --user user_b --password password -s nats://localhost:4773 ls

#=========CLEANUP=======

nats stream rm LEAF_IOT_STREAM -s nats://localhost:4775 --user user_leaf --password password
nats stream rm NODE1_IOT_STREAM -s nats://localhost:4772 --user user_a --password password
nats stream rm NODE2_IOT_STREAM -s nats://localhost:4773 --user user_b --password password
